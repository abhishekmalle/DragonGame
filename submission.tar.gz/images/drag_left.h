/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=46x40 drag_left drag_left.jpg 
 * Time-stamp: Tuesday 11/20/2018, 19:45:20
 * 
 * Image Information
 * -----------------
 * drag_left.jpg 46@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DRAG_LEFT_H
#define DRAG_LEFT_H

extern const unsigned short drag_left[1840];
#define DRAG_LEFT_SIZE 3680
#define DRAG_LEFT_LENGTH 1840
#define DRAG_LEFT_WIDTH 46
#define DRAG_LEFT_HEIGHT 40

#endif

