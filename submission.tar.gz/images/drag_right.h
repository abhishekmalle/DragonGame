/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=46x40 drag_right drag_right.jpg 
 * Time-stamp: Tuesday 11/20/2018, 19:45:08
 * 
 * Image Information
 * -----------------
 * drag_right.jpg 46@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DRAG_RIGHT_H
#define DRAG_RIGHT_H

extern const unsigned short drag_right[1840];
#define DRAG_RIGHT_SIZE 3680
#define DRAG_RIGHT_LENGTH 1840
#define DRAG_RIGHT_WIDTH 46
#define DRAG_RIGHT_HEIGHT 40

#endif

