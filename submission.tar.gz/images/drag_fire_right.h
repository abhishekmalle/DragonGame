/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=69x40 drag_fire_right drag_fire_right.jpg 
 * Time-stamp: Monday 11/19/2018, 19:44:42
 * 
 * Image Information
 * -----------------
 * drag_fire_right.jpg 69@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DRAG_FIRE_RIGHT_H
#define DRAG_FIRE_RIGHT_H

extern const unsigned short drag_fire_right[2760];
#define DRAG_FIRE_RIGHT_SIZE 5520
#define DRAG_FIRE_RIGHT_LENGTH 2760
#define DRAG_FIRE_RIGHT_WIDTH 69
#define DRAG_FIRE_RIGHT_HEIGHT 40

#endif

