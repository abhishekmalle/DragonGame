/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 castle castle.jpg 
 * Time-stamp: Monday 11/19/2018, 23:10:11
 * 
 * Image Information
 * -----------------
 * castle.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CASTLE_H
#define CASTLE_H

extern const unsigned short castle[38400];
#define CASTLE_SIZE 76800
#define CASTLE_LENGTH 38400
#define CASTLE_WIDTH 240
#define CASTLE_HEIGHT 160

#endif

