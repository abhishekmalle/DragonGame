/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=22x13 spider spider.jpg 
 * Time-stamp: Tuesday 11/20/2018, 16:09:46
 * 
 * Image Information
 * -----------------
 * spider.jpg 22@13
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPIDER_H
#define SPIDER_H

extern const unsigned short spider[286];
#define SPIDER_SIZE 572
#define SPIDER_LENGTH 286
#define SPIDER_WIDTH 22
#define SPIDER_HEIGHT 13

#endif

