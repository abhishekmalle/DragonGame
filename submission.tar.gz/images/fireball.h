/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=19x20 fireball fireball.jpg 
 * Time-stamp: Wednesday 11/21/2018, 00:20:41
 * 
 * Image Information
 * -----------------
 * fireball.jpg 19@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIREBALL_H
#define FIREBALL_H

extern const unsigned short fireball[380];
#define FIREBALL_SIZE 760
#define FIREBALL_LENGTH 380
#define FIREBALL_WIDTH 19
#define FIREBALL_HEIGHT 20

#endif

