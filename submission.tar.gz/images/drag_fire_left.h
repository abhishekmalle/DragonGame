/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=69x40 drag_fire_left drag_fire_left.jpg 
 * Time-stamp: Monday 11/19/2018, 19:44:31
 * 
 * Image Information
 * -----------------
 * drag_fire_left.jpg 69@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DRAG_FIRE_LEFT_H
#define DRAG_FIRE_LEFT_H

extern const unsigned short drag_fire_left[2760];
#define DRAG_FIRE_LEFT_SIZE 5520
#define DRAG_FIRE_LEFT_LENGTH 2760
#define DRAG_FIRE_LEFT_WIDTH 69
#define DRAG_FIRE_LEFT_HEIGHT 40

#endif

